package com.company;

public class Cat {
    // Name, Age, Gender, Color, Weight
    // ВСЕГДА ДЕЛАЙТЕ ПОЛЯ ЗАКРЫТЫМИ!!!
    // private -  m-
    // static - s-

    //
    public static final String COLOR_BLACK = "Black";
    public static final String COLOR_WHITE = "White";
    public static final String COLOR_GREY = "Grey";

    public static final String GENDER_MALE = "Male";
    public static final String GENDER_FEMALE = "Female";

    // Закрытые поля
    private String mName;
    private int mAge;
    private String mGender;  // Male, Female
    private String mColor;
    private double mWeight;

    // Конструктор класса
    // Alt + Insert

    // Пользовательский конструктор. Инициализирует поля класса исходя из того.
    //                               как описал программист
    public Cat(String mName,
               int mAge,
               String mGender,
               String mColor,
               double mWeight) {
        this.mName = mName;
        this.mAge = mAge;
        this.mGender = mGender;
        this.mColor = mColor;
        this.mWeight = mWeight;
    }

    // Конструктор по-умолчанию. Инициализирует поля класса по-умолчанию
    public Cat(){

    }

    // set-, get- методы доступа
    // Alt + Insert
    public String getName() {
        return mName;
    }

    public void setName(String mName) {
        this.mName = mName;
    }

    public int getAge() {
        return mAge;
    }

    public void setAge(int mAge) {
        if (mAge < 0 || mAge > 35) {
            System.out.println("Кошки столько не живут :)");
        } else {
            this.mAge = mAge;
        }
    }

    public String getGender() {
        return mGender;
    }

    public void setGender(String mGender) {
        this.mGender = mGender;
    }

    public String getColor() {
        return mColor;
    }

    public void setColor(String mColor) {
        this.mColor = mColor;
    }

    public double getWeight() {
        return mWeight;
    }

    public void setWeight(double mWeight) {
        this.mWeight = mWeight;
    }
}
