package com.company;

public class Main {

    public static void main(String[] args) {
        // write your code here
        Cat cat1 = new Cat("Matilda", 12, Cat.GENDER_FEMALE, Cat.COLOR_BLACK, 6);
        Cat cat2 = new Cat("Barsik", 13, Cat.GENDER_MALE, Cat.COLOR_WHITE, 10);
        Cat cat3 = new Cat("Garik", 23, Cat.GENDER_MALE, Cat.COLOR_GREY, 17);

        Cat cats[] = new Cat[3];
        cats[0] = cat1;
        cats[1] = cat2;
        cats[2] = cat3;
        for (int i = 0; i < cats.length; i++) {
            System.out.println("Name : " + cats[i].getName());
            System.out.println("Age:" + cats[i].getAge());
            System.out.println("Gender:" + cats[i].getGender());
            System.out.println("Color:" + cats[i].getColor());
            System.out.println("Weight:" + cats[i].getWeight());
            System.out.println("----------------------------------------");
        }
        Dog dog1=new Dog("Sharik",22,Dog.GENDER_MALE,Dog.COLOR_GREEN,6);
        Dog dog2=new Dog("Dog1",32,Dog.GENDER_MALE,Dog.COLOR_GREEN,8);
        Dog dog3=new Dog("Dog2",11,Dog.GENDER_MALE,Dog.COLOR_GREEN,13);
        Dog dogs[] = new Dog[3];
        dogs[0]=dog1;
        dogs[1]=dog2;
        dogs[2]=dog3;
        for (int i = 0; i < dogs.length; i++) {
            System.out.println("Name : " + dogs[i].getName());
            System.out.println("Age:" + dogs[i].getAge());
            System.out.println("Gender:" + dogs[i].getGender());
            System.out.println("Color:" + dogs[i].getColor());
            System.out.println("Weight:" + dogs[i].getWeight());
            System.out.println("----------------------------------------");
        }
    }
}
