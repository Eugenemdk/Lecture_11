package com.company;

public class Dog {
    // Name, Age, Gender, Color, Weight
    public static final String COLOR_ORANGE = "Orange";
    public static final String COLOR_GREEN = "Green";
    public static final String COLOR_YELLOW = "Yellow";

    public static final String GENDER_MALE = "Male";
    public static final String GENDER_FEMALE = "Female";


    private String mName;
    private int mAge;
    private String mGender;
    private String mColor;
    private double mWeight;

    public Dog(String mName,
               int mAge,
               String mGender,
               String mColor,
               double mWeight) {
        this.mName = mName;
        this.mAge = mAge;
        this.mGender = mGender;
        this.mColor = mColor;
        this.mWeight = mWeight;
    }


    public Dog() {

    }

    public String getName() {
        return mName;
    }

    public void setName(String mName) {
        this.mName = mName;
    }

    public int getAge() {
        return mAge;
    }

    public void setAge(int mAge) {
        this.mAge = mAge;
    }

    public String getGender() {
        return mGender;
    }

    public void setGender(String mGender) {
        this.mGender = mGender;
    }

    public String getColor() {
        return mColor;
    }

    public void setColor(String mColor) {
        this.mColor = mColor;
    }

    public double getWeight() {
        return mWeight;
    }

    public void setWeight(double mWeight) {
        this.mWeight = mWeight;
    }
}
