package com.company;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String name;
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите своё имя: ");
        name = scanner.next();

        Game game = new Game(name);
    }
}