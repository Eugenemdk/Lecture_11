package com.company;
public class Stopwatch {

    long startTime = System.currentTimeMillis();

    public Stopwatch() {
        try {
            while (true) {
                //Clear Console
                for (int i = 0; i < 30; i++)
                    System.out.println();
                // geting Time in desire format
                System.out.print(getTimeElapsed());
                // Thread sleeping for 1 sec
                Thread.currentThread().sleep(1000);
            }
        } catch (Exception e) {
            System.out.print("Exception in Thread Sleep : " + e);
        }
    }

    public String getTimeElapsed() {
        long elapsedTime = System.currentTimeMillis() - startTime;
        elapsedTime = elapsedTime / 1000;

        String seconds = Integer.toString((int) (elapsedTime % 60));
        String minutes = Integer.toString((int) ((elapsedTime % 3600) / 60));
        String hours = Integer.toString((int) (elapsedTime / 3600));

        if (seconds.length() < 2)
            seconds = "0" + seconds;

        if (minutes.length() < 2)
            minutes = "0" + minutes;

        if (hours.length() < 2)
            hours = "0" + hours;

        return minutes + ":" + seconds;
    }
}