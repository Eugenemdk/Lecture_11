package com.company;

import java.util.Random;
import java.util.Scanner;

public class Game {
    final String UP = "w";
    final String DOWN = "s";
    final String LEFT = "a";
    final String RIGHT = "d";
    // Время начала игры в ms
    long startTime;
    // Время окончания игры в ms
    long endTime;

    //поля класса
    int columnCount = 0; //столбцы
    int rowCount = 0; //строки
    char player = (char) (0x25CF); // 25CF - код символа "черный круг"
    char barrier = (char) (0x25A0); //25AO - код символа "черный квадрат"
    char wallsHor = (char) (0x25A4); //25A3 - код символа "квадрат с вложенным кадратом"
    char wallsVer = (char) (0x25A5); //25A5 - код символа "квадрат с горизонтальным заполнением"
    char finish = (char) (0x25A3); //25A4 - код символа "квадрат с вертикальным заполнением"
    char blackDiamond = (char) (0x25C6);
    char whiteDiamond = (char) (0x25C7);//25c7 - код символа "белый кристал"

    char test3;
    char test2;
    char test;
    int countOfSteps = 0;
    int countOfDiamonds = 0;
    boolean isWin = false;

    int startPositionColumn;
    int secondPositionColumn;
    int thirdPositionColumn;

    Scanner scanner = new Scanner(System.in);
    String nameOfPlayer;

    String name1;
    String name2;
    int countOfDiamonds1;
    int countOfDiamonds2;

    // Лабиринт
    char[][] labirynth;

    // Позиция игрока, в момент начала хода (строка)
    int startStepPositionRow = 1;
    // Позиция игрока, в момент начала хода (столбец)
    int startStepPositionColumn;

    // Позиция, на которую персонаж хочет перейти (строка)
    int targetStepPositionRow = 0;
    // Позиция, на которую персонад хочет перейти (столбец)
    int targetStepPositionColumn = 0;
    //--------------------------------------------

    // Конструктор класса
    // Инициализация полей класса
    Game(String nameOfPlayer) {
        this.nameOfPlayer = nameOfPlayer;
        initializeMaze();
        start();
    }
    // --------------------------------------------------------
    // Методы
    // Инициализирует лабиринт
    private void initializeMaze() {
        do {
            System.out.print("Введите количество строк [10;50]: ");
            rowCount = scanner.nextInt();

            if (rowCount >= 10 && rowCount <= 50) { //проверка на корректность данных
                break;
            }
            System.out.println("Неправильно");
        } while (true);

        //ввод с клавиатуры количества столбцов
        do {
            System.out.print("Введите количество столбцов [10;50]: ");
            columnCount = scanner.nextInt();

            if (columnCount >= 10 && columnCount <= 50) {
                break;
            }
            System.out.println("Неправильно");
        } while (true);

        //создание массива для поля лабиринта
        labirynth = new char[rowCount][columnCount];

        //создание барьера
        for (int i = 0; i < rowCount; i++) {
            for (int j = 0; j < columnCount; j++) {
                labirynth[i][j] = barrier;
            }
        }

        //создание переменной для генерации позиции player
        Random random = new Random();
        startPositionColumn = random.nextInt(columnCount - 2) + 1;
        secondPositionColumn = random.nextInt(columnCount - 2) + 1;
        thirdPositionColumn = random.nextInt(columnCount - 2) + 1;
        startStepPositionColumn = startPositionColumn;

        //вывод на экран начальной позиции player
        labirynth[1][startPositionColumn] = player;

        //заполнение горизонтальных стен лабиринта
        for (int i = 0; i < labirynth[1].length; i++) {
            labirynth[0][i] = wallsHor;
            labirynth[rowCount - 1][i] = wallsHor;
        }

        //заполнение вертикальных стен лабиринта
        for (int i = 0; i < labirynth.length; i++) {
            labirynth[i][0] = wallsVer;
            labirynth[i][columnCount - 1] = wallsVer;
        }

        //указывание финиша в лабиринте
        labirynth[rowCount - 2][columnCount - 2] = finish;

        //создание пути по вертикали
        for (int i = 2; i <= rowCount - 9; i++) {
            if (player == finish) continue;
            labirynth[i][startPositionColumn] = blackDiamond;
        }

        for (int i = startPositionColumn; i < secondPositionColumn ; i++) {
            if (labirynth[rowCount - 9][i] == finish) continue;
            labirynth[rowCount - 9][i] = blackDiamond;
        }

        for (int i = rowCount - 9; i < columnCount - 2 ; i++) {
            if(labirynth[i][secondPositionColumn] == finish) continue;
            labirynth [i][secondPositionColumn] = blackDiamond;
        }

        for (int i = startPositionColumn; i < thirdPositionColumn ; i++) {
            if (labirynth[rowCount - 7][i] == finish) continue;
            labirynth[rowCount - 7][i] = blackDiamond;
        }

        for (int i = rowCount - 7; i < columnCount - 2 ; i++) {
            if(labirynth[i][thirdPositionColumn] == finish) continue;
            labirynth [i][thirdPositionColumn] = blackDiamond;
        }

        for (int i = startPositionColumn; i < secondPositionColumn; i++) {
            if(labirynth[rowCount - 9][i] == finish) continue;
            labirynth[rowCount - 9][i] = blackDiamond;
        }

        for (int i = startPositionColumn + 1; i < columnCount - 1 ; i++) {
            if(labirynth[1][i] == finish) continue;
            labirynth[1][i] = blackDiamond;
        }

        for (int i = 3; i < thirdPositionColumn ; i++) {
            if(labirynth[i][1] == finish)continue;
            labirynth[i][1] = blackDiamond;
        }

        //создание пути по горизонтали до финиша
        for (int i = secondPositionColumn; i < columnCount - 2; i++) {
            if (labirynth[rowCount - 2][i] == finish) continue;
            labirynth[rowCount - 2][i] = blackDiamond;
        }

        //остальные пути
        for (int i = 2; i < labirynth.length-2; i++) {
            for (int j = 2; j < labirynth[i].length-2; j++) {
                int flag = random.nextInt(9);

                if (flag == 0){
                    labirynth[i][j] = blackDiamond;
                    labirynth[i][j+1] = blackDiamond;
                    labirynth[i+1][j+1] = blackDiamond;
                }
            }
        }
    }

    // Вывод лабиринта на экран
    private void showMaze() {
        //вывод лабиринта на экран
        for (int i = 0; i < rowCount; i++) {
            for (int j = 0; j < columnCount; j++) {
                System.out.print(labirynth[i][j]);
            }
            System.out.println();
        }

        System.out.println("Сделано - " + countOfSteps + " ходов");
        System.out.println("Ты собрал - " + countOfDiamonds + " бриллиантов");
    }

    private void start() {
        // setPlayer();
        gameProcess();
    }

    private void setPlayer() {
        test3 = (char) (0x25CF);
        test2 = (char) (0x06DD);
        test = (char) (0x0A66);
        System.out.println("Выберите персонажа: 1 - " + test + ", 2 - " + test2 + ", 3 - " + test3);
        int currentPlayer = scanner.nextInt();
        if (currentPlayer == 1)
            player = test;
        else if(currentPlayer == 2)
            player = test2;
        else
            player = test3;
    }

    private void Comparing(){
        nameOfPlayer = name1;
        nameOfPlayer = name2;
        countOfDiamonds = countOfDiamonds1;
        countOfDiamonds = countOfDiamonds2;
        System.out.println("Рекорды:");
        System.out.println(countOfDiamonds1);
        System.out.println(countOfDiamonds2);


    }
    // Основной метод игры
    private void gameProcess() {
        startTime = System.currentTimeMillis();
        System.out.println(nameOfPlayer + ", тебе брошено испытание! Докажи, что ты крут :)");
        while (!isWin) {
            showMaze();
            String step = userInput();

            boolean isSetPositionDone = false;
            switch (step) {
                case UP:
                    isSetPositionDone = setPlayerPosition(0, -1);
                    break;
                case DOWN:
                    isSetPositionDone = setPlayerPosition(0, 1);
                    break;
                case LEFT:
                    isSetPositionDone = setPlayerPosition(-1, 0);
                    break;
                case RIGHT:
                    isSetPositionDone = setPlayerPosition(1, 0);
                    break;
                default:
                    System.out.println("Юзер мега-долбадятел");
                    break;
            }

            if (!isSetPositionDone)
                System.out.println("Вы не можете туда пойти!");

            abstactClear();
        }

        // Когда мы наконец-то выйграли
        win();
    }

    // Метод для пользовательского ввода
    private String userInput() {
        String answer = "";

        do {
            System.out.println("Куда игроку пойти: w - вверх, s - вниз, a - влево, d - вправо");
            System.out.print("Ход: ");
            answer = scanner.next();

            // Приводим к нижнему регистру
            answer = answer.toLowerCase();
        }
        while (!(answer.equals(UP) || answer.equals(DOWN) ||
                answer.equals(LEFT) || answer.equals(RIGHT)));

        return answer;
    }

    // Очистка консоли (фейковая)
    private void abstactClear() {
        String abstractClear = "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";

        System.out.println(abstractClear);
    }

    // Метод для перемещения  персонажа.
    // Возвращает true, если перемещение удалось
    // Возвращает false, если перемещение не удалось
    private boolean setPlayerPosition(int x, int y) {
        targetStepPositionRow = startStepPositionRow + y;
        targetStepPositionColumn = startStepPositionColumn + x;

        if (labirynth[targetStepPositionRow][targetStepPositionColumn] == blackDiamond ||
                labirynth[targetStepPositionRow][targetStepPositionColumn] == whiteDiamond ||
                labirynth[targetStepPositionRow][targetStepPositionColumn] == finish) {

            if (labirynth[targetStepPositionRow][targetStepPositionColumn] == finish) {
                labirynth[targetStepPositionRow][targetStepPositionColumn] = player;
                labirynth[startStepPositionRow][startStepPositionColumn] = whiteDiamond;
                isWin = true;
            } else if (labirynth[targetStepPositionRow][targetStepPositionColumn] == blackDiamond) {
                ++countOfDiamonds;
                labirynth[targetStepPositionRow][targetStepPositionColumn] = player;
                labirynth[startStepPositionRow][startStepPositionColumn] = whiteDiamond;
            } else {
                labirynth[targetStepPositionRow][targetStepPositionColumn] = player;
                labirynth[startStepPositionRow][startStepPositionColumn] = whiteDiamond;
            }
            startStepPositionRow = targetStepPositionRow;
            startStepPositionColumn = targetStepPositionColumn;

            ++countOfSteps;
            return true;
        } else {
            return false;
        }
    }

    // Вызывется, при победе
    private void win() {
        endTime = System.currentTimeMillis();
        showMaze();
        System.out.println(nameOfPlayer + " победил! И ты мега крут!");
        System.out.println("Понадобилось времени - " + (endTime - startTime) + " ms");
        System.out.println(nameOfPlayer + ", твой звездный путь выше :)");
    }
}