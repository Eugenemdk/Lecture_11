package com.company;

public class Record {
    // Имя игрока
    private String playerName;

    // Количество брилиантов
    private int countOfDiamonds;

    // Количество строк в лабиринте
    private int rowCount;

    // Количество столбцов в лабиринте
    private int columnCount;

    // Конструктор класса
    public Record(String playerName, int countOfDiamonds, int rowCount, int columnCount) {
        this.playerName = playerName;
        this.countOfDiamonds = countOfDiamonds;
        this.rowCount = rowCount;
        this.columnCount = columnCount;
    }

    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    public int getCountOfDiamonds() {
        return countOfDiamonds;
    }

    public void setCountOfDiamonds(int countOfDiamonds) {
        this.countOfDiamonds = countOfDiamonds;
    }

    public int getRowCount() {
        return rowCount;
    }

    public void setRowCount(int rowCount) {
        this.rowCount = rowCount;
    }

    public int getColumnCount() {
        return columnCount;
    }

    public void setColumnCount(int columnCount) {
        this.columnCount = columnCount;
    }

    // Метод для вывода рекорда на экран
    public void showRecord() {
        System.out.print(this.playerName + "  " + this.countOfDiamonds + "  " + rowCount + "x" + columnCount);
        System.out.println();
    }
}
