package com.company;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        String name;
        ArrayList<Record> recordList = new ArrayList<>();

        // Имена пользователей
        Scanner scanner = new Scanner(System.in);

        String gameMode;

        // Проверку на корректность ввода
        System.out.println("Какой режим игры Вы выберете?");
        System.out.println(" Одиночный - введите single");
        System.out.println(" Многопользовательский - введите mult");
        System.out.println(" Для выхода - введите exit");

        do {
            System.out.print("Ваш выбор: ");
            gameMode = scanner.next();

            switch (gameMode.toLowerCase()) {
                case "single":
                    System.out.print("Введите своё имя: ");
                    name = scanner.next();

                    // Отыграли
                    Game game = new Game(name);
                    // Создаем объект типа Record, который хранит информацию о рекордах
                    Record record =
                            new Record(game.nameOfPlayer, game.countOfDiamonds, game.rowCount, game.columnCount);
                    recordList.add(record);

                    break;
                case "mult":
                    System.out.println("mult");
                    System.out.print("Введите своё имя: ");
                    name = scanner.next();
                    String name1 = name;

                    Game game2 = new Game(name);
                    String[] namesOfPlayers;

                    for (int i = 0; i < 5; i++) {
                        //  NameOfPlayers name1 = new NameOfPlayers();
                        // namesOfPlayers [i];
                    }
                    break;
                case "exit":
                    System.out.println("GAME OVER");
                    break;
                default:
                    System.out.println("Введите ещё раз");
                    break;
            }

            System.out.println("\n\n\n");
            System.out.println("------------------------------------");
            System.out.println("Рекорды: ");
            for (Record record :recordList) {
                record.showRecord();
            }
            System.out.println("\n------------------------------------");
            System.out.println("\n\n\n");
        }while (true) ;
    }
}