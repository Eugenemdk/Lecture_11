package com.company;
import java.util.Random;
import java.util.Scanner;

public class Main {
    // TODO: 27.10.2017 Добавить генерацию случайного пути
    // TODO: 27.10.2017 Добавить пользовательский ввод
    // TODO: 27.10.2017 Добавить счетчик ходов
    // TODO: 27.10.2017 Добавить сч-етчик диамантов
    // TODO: 27.10.2017 Добавить счетчик времени для прохождения
    // TODO: 27.10.2017 Перенести на процедурное программирование
    // TODO: 27.10.2017 Перенести на ООП

    public static void main(String[] args) {


        int m;  // столбцы
        int n;  // строки
        Scanner scan = new Scanner(System.in);
        char player = (char) (0x25CF);// 25CF - код символа "черный круг", 16-тиричной системе счисления
        char barrier = (char) (0x25A0); // 25AO - код символа "черный квадрат", 16-тиричной системе счисления
        char finish = (char) 0x25A3;// 25A3 - код символа "квадрат с вложенным кадратом", 16-тиричной системе счисления
        char wallHorizontal = (char) 0x25A5;// 25A5 - код символа "квадрат с горизонтальным заполнением", 16-тиричной системе счисления
        char wallVertical = (char) 0x25A4;// 25A4 - код символа "квадрат с вертикальным заполнением", 16-тиричной системе счисления
        char blackDiamond = (char) 0x25C6;
        char whiteDiamond = (char) 0x25C7;

        //System.out.println(barier);
        //System.out.println(player);
        //Создание цикла do while,ввод с клавиатуры колличества строк,проверка на
        //ввод некорретных данных
        do {
            System.out.print("Введите количество строк: ");
            n = scan.nextInt();

            if (n >= 10 && n <= 30) {
                // Завершение выполнения цикла
                break;
            }
            System.out.println("Некорректные данные");
        } while (true);
//Создание цикла do while,ввод с клавиатуры колличества столбцов,проверка на
//ввод некорретных данных
        do {
            System.out.print("Введите количество столбцов: ");
            m = scan.nextInt();

            if (m >= 10 && m <= 30) {
                break;
            }
            System.out.println("Некорректные данные");
        } while (true);

        // Создание массива
        char[][] labirint = new char[n][m];
        //Создание барьера
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                labirint[i][j] = barrier;
            }
        }
        //Создание переменной для генерации случайных чисел
        Random random = new Random();
        //Создание переменной для генерации позиции player
        int startPositionColumn = random.nextInt(m - 2) + 1;
//Создание цикла для заполнения вертикальных стенок лабиринта
        for (int i = 0; i < labirint.length; i++) {
            labirint[i][0] = wallHorizontal;
            labirint[i][m - 1] = wallHorizontal;
        }
//Создание цикла для заполнения горизонтальных стенок лабиринта
        for (int i = 0; i < labirint.length; i++) {
            labirint[0][i] = wallVertical;
            labirint[n - 1][i] = wallVertical;
        }
        //  [0,m)
        // Указываем финиш
        labirint[n - 2][m - 2] = finish;

        // Помещаем игрока в начальное положение
        labirint[1][startPositionColumn] = player;

        // Создаем путь
        for (int i = 2; i <= n - 2; i++) {
            if (labirint[i][startPositionColumn] == finish) continue;
            labirint[i][startPositionColumn] = blackDiamond;

            int flag = random.nextInt(2);

            if (flag == 0){
                int rowIndex = random.nextInt(n-3)+2;
                int columnIndex = random.nextInt(m-3)+1;

                labirint[rowIndex][columnIndex] = blackDiamond;
            }
        }

        // Создаем путь
        for (int i = startPositionColumn; i <= m - 2; i++) {
            if (labirint[n - 2][i] == finish) continue;

            labirint[n - 2][i] = blackDiamond;

            int flag = random.nextInt(2);

            if (flag == 0){
                int rowIndex = random.nextInt(n-3)+2;
                int columnIndex = random.nextInt(m-3)+1;

                labirint[rowIndex][columnIndex] = blackDiamond;
            }
        }

        // Выводим лабиринт на экран
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                System.out.print(labirint[i][j]);
            }
            System.out.println();
        }

        // Через switch делай
    }
}
